export interface Contact {
        contactId: number,
        contactName: string,
        emailId: string,
        contactPassword: string,
        contactContactNumber: string,
        contactAddress: string,
        contactGender: string,
        contactJob: string,
       
}
