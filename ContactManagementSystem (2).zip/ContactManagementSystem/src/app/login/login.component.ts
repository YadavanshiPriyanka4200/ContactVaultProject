import { Component } from '@angular/core';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';


@Component({
  selector: 'app-login',
  standalone: false,
  
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

  loginObj: any = {
    username:'',
    password:''
  };
  
  // router = inject(Router);
  constructor(private router: Router) {}

  
  onLogin() {
    if(this.loginObj.username == "admin" && this.loginObj.password =="112233") {
      Swal.fire({
        title: 'Login Successful!',
        text: 'Welcome to the ContactManagementAPP',
        icon: 'success',
        confirmButtonText: 'OK'
      });
      this.router.navigateByUrl('home')
    } else {
      Swal.fire({
        title: 'Invalid!',
        text: 'Invalid login credential.',
        icon: 'error',
        confirmButtonText: 'OK'
      });
      // alert("Wrong Credentials")
    }
  }
}
