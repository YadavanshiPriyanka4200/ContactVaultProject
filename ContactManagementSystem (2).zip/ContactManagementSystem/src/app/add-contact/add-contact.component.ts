import { Component } from '@angular/core';
import Swal from 'sweetalert2';
import { NgForm } from '@angular/forms';
import { ContactService } from '../contact.service';
import { Contact } from '../contact';
@Component({
  selector: 'app-add-contact',
  standalone: false,
  
  templateUrl: './add-contact.component.html',
  styleUrl: './add-contact.component.css'
})
export class AddContactComponent {
  contact : Contact = {
    contactId: 0,
    contactName: '',
    emailId: '',
    contactPassword: '',
    contactContactNumber: '',
    contactAddress: '',
    contactGender: '',
    contactJob: '',
   
  };

  constructor(private contactService: ContactService) {}

  //  Method to handle form submission
    onSubmit(form: NgForm) {
    if (form.valid) {
      this.contactService.saveContact(this.contact).subscribe(
        (response) => {
          // console.log('Contact saved successfully:', response);
              // Display a success popup
          Swal.fire({
            title: 'Success!',
            text: 'Contact saved successfully.',
            icon: 'success',
            confirmButtonText: 'OK'
          });
          form.reset();
        },
        (error) => {
          // console.error('Error saving contact:', error);
                    // Display an error popup
                    Swal.fire({
                      title: 'Error!',
                      text: 'There was a problem saving the contact. Please try again later.',
                      icon: 'error',
                      confirmButtonText: 'OK'
                    });
          
        }
      );
    }
    }
}
