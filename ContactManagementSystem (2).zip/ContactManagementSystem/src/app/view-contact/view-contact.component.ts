import { Component ,OnInit} from '@angular/core';
import { ContactService } from '../contact.service';


@Component({
  selector: 'app-view-contact',
  standalone: false,
  
  templateUrl: './view-contact.component.html',
  styleUrl: './view-contact.component.css'
})
export class ViewContactComponent implements OnInit {
  contacts: any[] = [];
  isEdit: boolean = false; // Tracks whether the form is in edit mode
  selectedContact: any = {};

  constructor(private contactService: ContactService) {}

  ngOnInit(): void {
    this.getContacts();
  }

  getContacts(): void {
    this.contactService.getContacts().subscribe(
      (data: any[]) => {
        this.contacts = data;
      },
      (error) => {
        console.error('Error fetching contact data', error);
      }
    );
  }

  deleteContact(contactId: number): void {
    if (confirm('Are you sure you want to delete this contact?')) {
      this.contactService.deleteContact(contactId).subscribe(
        () => {
          this.contacts = this.contacts.filter(contact => contact.contactId !== contactId);
          alert('Contact deleted successfully');
        },
        (error) => {
          console.error('Error deleting contact', error);
          alert('Failed to delete contact. Please try again.');
        }
      );
    }
  }

  onEdit(contact: any): void {
    this.isEdit = true;
    this.selectedContact = { ...contact }; // Clone the selected contact to avoid direct binding
  }

  saveContact(): void {
    if (this.isEdit) {
      this.contactService.updateContact(this.selectedContact).subscribe(
        (updatedContact) => {
          // Update the local contactlist with the new data
          const index = this.contacts.findIndex(
            contact => contact.contactId === updatedContact.contactId
          );
          if (index !== -1) {
            this.contacts[index] = updatedContact; // Replace with updated data
          }
          this.isEdit = false; // Exit edit mode
          alert('Contact updated successfully');
        },
        (error) => {
          console.error('Error updating contact', error);
          alert('Failed to update contact. Please try again.');
        }
      );
    }
  }
}
