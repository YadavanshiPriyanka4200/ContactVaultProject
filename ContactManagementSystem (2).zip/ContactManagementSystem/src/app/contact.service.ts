import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ContactService {

  private baseUrl = 'http://localhost:8090'; // Spring Boot backend URL

  constructor(private http: HttpClient) {}

  saveContact(contact: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/save/contact`, contact);
  }

  getContacts(): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/get/contact`);
  }

  // contact.service.ts
  deleteContact(contactId: number): Observable<void> {
    // const url = ${this.baseUrl}/delete/contact/{contactId};
    return this.http.delete<void>(`${this.baseUrl}/delete/contact/${contactId}`);
  }

  updateContact(contact: any): Observable<any> {
    const url = `${this.baseUrl}/update/contact`;
    return this.http.put<any>(url, contact);
  }
}
