package myPack.cmsApp.Dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;

public class LoginRequest {
	@NotEmpty(message = "cannot be Empty.")
	@Email(message = "Email is not Valid.")
	private String emailId;
	
	@NotEmpty(message = "Cannot be empty.")
	@Size(min=8, message = "must contail upper case, special character and anumber")
	private String contactPassword;

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getContactPassword() {
		return contactPassword;
	}

	public void setContactPassword(String contactPassword) {
		this.contactPassword = contactPassword;
	}
	
	
}
