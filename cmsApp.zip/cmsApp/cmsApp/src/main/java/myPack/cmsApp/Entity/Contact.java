package myPack.cmsApp.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

@Entity
@SequenceGenerator(name = "generator1", sequenceName = "gen1", initialValue = 1)
public class Contact {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "generator1")    
    private Integer contactId;
    
    @NotEmpty
	@Size(min=3 , message="firstName must contain atleast 3 characters")
    private String contactName;
    
    @Column(name="email_id", unique = true, length = 30)
    @NotEmpty
    @Email(message = "Email is not valid")
    private String emailId;
    
    @NotEmpty
	@Size(min=8, message="Password length must be 8 and contain uppercase,lowercase,digits")
	//@Pattern(regexp="(?=.\\d)(?=.*[a-z])(?=.*[A-Z]).{8,}")
    private String contactPassword;
    
    @NotEmpty
	@Size(min=10 ,max=10, message="phoneNumber must contain  10 digits")
    private String contactContactNumber;
    
    @NotEmpty(message = "Address can not be empty")
    private String contactAddress;
    
    @NotEmpty(message = "Gender can not be empty")
    private String contactGender;
    
    @NotEmpty(message = "Job can not be empty")
    private String contactJob;

	public Integer getContactId() {
		return contactId;
	}

	public void setContactId(Integer contactId) {
		this.contactId = contactId;
	}

	public String getContactName() {
		return contactName;
	}

	public void setContactName(String contactName) {
		this.contactName = contactName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getContactPassword() {
		return contactPassword;
	}

	public void setContactPassword(String contactPassword) {
		this.contactPassword = contactPassword;
	}

	public String getContactContactNumber() {
		return contactContactNumber;
	}

	public void setContactContactNumber(String contactContactNumber) {
		this.contactContactNumber = contactContactNumber;
	}

	public String getContactAddress() {
		return contactAddress;
	}

	public void setContactAddress(String contactAddress) {
		this.contactAddress = contactAddress;
	}

	public String getContactGender() {
		return contactGender;
	}

	public void setContactGender(String contactGender) {
		this.contactGender = contactGender;
	}

	public String getContactJob() {
		return contactJob;
	}

	public void setContactJob(String contactJob) {
		this.contactJob = contactJob;
	}
    
}
