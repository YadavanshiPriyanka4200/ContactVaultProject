package myPack.cmsApp.Dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import myPack.cmsApp.Entity.Contact;

@Repository
public interface ContactDao extends JpaRepository<Contact, Integer> {
	
		Optional<Contact> findByContactName(String contactName);
		
		Optional<Contact> findByEmailIdAndContactPassword(String email, String password);	//method t find contact email and password

}
