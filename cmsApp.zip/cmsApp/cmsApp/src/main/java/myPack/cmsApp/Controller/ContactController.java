package myPack.cmsApp.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import myPack.cmsApp.Dto.LoginRequest;
import myPack.cmsApp.Entity.Contact;
import myPack.cmsApp.Service.ContactService;



@RestController
@CrossOrigin("http://localhost:4200")	//4200 is the front end port number
public class ContactController {
	@Autowired
	ContactService contactService;
	
	@PostMapping("/save/contact")	//can give your own name //also called as endpoints
	public Contact saveContact(@RequestBody Contact contact) {
		return contactService.saveContact(contact);
	}
	
	@GetMapping("/get/contact")
	public List<Contact> getContacts(){
		return contactService.getContacts();
	}
	
	@GetMapping("/get/contact/{contactId}")
	public Contact getContact(@PathVariable Integer contactId) {		//path variable is used to capture value from URL and put in code
		return contactService.getContact(contactId);
	}
	
	@PutMapping("/update/contact")
    public ResponseEntity<Contact> updateContact(@RequestBody Contact contact) 
    {
        Contact updatedContact = contactService.updateContact(contact);
        if (updatedContact != null) {
            return ResponseEntity.ok(updatedContact);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }
	
	@DeleteMapping("/delete/contact/{contactId}")
	public void deleteContact(@PathVariable Integer contactId) {
		contactService.deleteContact(contactId);
	}
	
	// Endpoint to get contact by name
    @GetMapping("/name/{contactName}")
    public ResponseEntity<Contact> getContactByName(@PathVariable String contactName)
    {
    	Contact contact = contactService.getContactByName(contactName);
        return ResponseEntity.ok(contact);
    }
    
    //Endpoint for login
    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody LoginRequest loginrequest){
		
    	Contact contact;
			try {
				contact = contactService.login(loginrequest.getEmailId(), loginrequest.getContactPassword());
				return ResponseEntity.ok("Welcome, "+contact.getContactName());
			} catch (Exception e) {
				return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(e.getMessage());
			}
    }
}
