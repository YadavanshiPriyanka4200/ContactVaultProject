package myPack.cmsApp.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import myPack.cmsApp.Dao.ContactDao;
import myPack.cmsApp.Entity.Contact;

@Service
public class ContactService {
 
	@Autowired
	ContactDao contactDao;
	//to insert a new record
	public Contact saveContact(Contact contact) {
		return contactDao.save(contact);
		
	}
	
	public List<Contact> getContacts(){
		List<Contact> contacts = new ArrayList<Contact>();
		contactDao.findAll().forEach(contacts::add);
		return contacts;
		
	}
	
	public Contact getContact(Integer contactId) {
		return contactDao.findById(contactId).orElseThrow();
	}
	
	public void deleteContact(Integer contactId) {
		contactDao.deleteById(contactId);
	}
	
	public Contact updateContact(Contact saveContact) {
		 contactDao.findById(saveContact.getContactId()).orElseThrow();
		 return contactDao.save(saveContact);
	}
	
	// Search employee by name
    public Contact getContactByName(String contactName) {
        return contactDao.findByContactName(contactName)
                .orElseThrow(() -> new RuntimeException("Contact not found with name: " + contactName));
    }
    
    //method for login
    public Contact login(String emailId, String password) {
    	return contactDao.findByEmailIdAndContactPassword(emailId, password).orElseThrow(()->new RuntimeException("Invalid email or password"));
    }
}
